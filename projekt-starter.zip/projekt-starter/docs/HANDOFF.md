# HANDOFF

Wird vom Agent nach JEDER Aufgabe komplett neu geschrieben (nicht angehängt).
Ziel: Eine neue Sitzung ohne Gedächtnis kann in 2 Minuten weiterarbeiten.

Aktualisiert: [JJJJ-MM-TT HH:MM]     Von: Agent     Letzte Karte: [T00]

## 1. Stand in 3 Sätzen
[Was funktioniert jetzt? Was ist als Letztes passiert? Wo steht das Projekt im Plan?]

## 2. Nächster Schritt
- Karte: [Txx: Titel]
- Erster konkreter Handgriff: [z. B. "Datei src/x.py öffnen, Funktion y ergänzen"]

## 3. Erledigt in dieser Sitzung
- [Txx]: [Ergebnis] (Dateien: [..])

## 4. Geänderte Dateien
- [Pfad]: [Was und warum, 1 Zeile]

## 5. Prüfstand
- Test-Befehl: [..]  Ergebnis: [x bestanden, y fehlgeschlagen]
- Manuell geprüft: [Schritt -> Ergebnis]

## 6. Blockiert / Probleme
- [Fehlertext oder Beschreibung] | Versuche: [..] | Vermutung: [..]

## 7. Fragen an den Menschen
1. [Frage] Vorschlag A: [..] / Vorschlag B: [..] / Empfehlung: [..]

## 8. Vorschläge an den Architect
- [Änderungswunsch an Architektur/Plan mit Grund]

## 9. Wichtiges, das nirgends sonst steht
- [Fallen, Tricks, Eigenheiten, Befehle, die funktionieren]
